/** Automatically generated file. DO NOT MODIFY */
package ics.cs237.childseekingapp.activity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}