/**
 * 
 */
package ics.cs237.childseeking.activity;

import java.io.ByteArrayInputStream;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

/**
 * @author CHazyhabiT
 *
 */
public class AsyncSender {
	
	 private static String uploadUrl = "http://169.234.51.148/project234/config/db_connect.php";
	 private static AsyncHttpClient client;
	 
	 public AsyncSender() {
		 client = new AsyncHttpClient();
	 }
	 
	 public static void upLoadImage(byte[] fileBytes) {
			

			RequestParams params = new RequestParams();
			params.put("image", new ByteArrayInputStream(fileBytes));
			
			client.post(uploadUrl, params, new AsyncHttpResponseHandler() {
				
				@Override
				public void onSuccess(int arg0, String arg1) {
//					super.onSuccess(arg0, arg1);
					
				}
				
			});
			
		}
		
		public static void upLoadString(String key, String value) {
			RequestParams params = new RequestParams();
			params.put(key, value);
			
			client.post(uploadUrl, params, new AsyncHttpResponseHandler() {
				@Override
				public void onSuccess(int arg0, String arg1) {
//					super.onSuccess(arg0, arg1);
					
				}

			});
			
		}

}
