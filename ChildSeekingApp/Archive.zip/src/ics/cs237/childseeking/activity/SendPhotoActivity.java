package ics.cs237.childseeking.activity;

import ics.cs237.childseeking.filehelper.FileHelper;
import ics.cs237.childseekingapp.activity.R;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.squareup.picasso.Picasso;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

/**
 * @author CHazyhabiT
 * 
 */
public class SendPhotoActivity extends Activity {
	
	public static final String TAG = SendPhotoActivity.class.getSimpleName();
	public static final String TYPE_IMAGE = "image";
	
	// request
	private static final int TAKE_PHOTO_REQUEST = 1;
	public String photoName;

	
	private boolean isCurrentImageSubmitted = false;
			
	// UI component
	private ImageView mImageView;
	private EditText mEditText;
	private Button mRetakeButton;
	private Button mSubmitButton;
	
	
	private LocationManager mLocationManager;
	// photo
	
	private ByteArrayOutputStream mBytes;
	private Uri mMediaUri = null;
	private Bitmap mPhoto;
	// additional info
	private String mComment;
	private String mTimeStamp;
	private Location mLocation;
	
			
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.send_photo_activity);

		// UI component
		mImageView = (ImageView) findViewById(R.id.imageView1);
		mEditText = (EditText) findViewById(R.id.editText1);
		mRetakeButton = (Button) findViewById(R.id.button_retake);
		mSubmitButton = (Button) findViewById(R.id.button_submit);
		
		// Acquire reference to the LocationManager
		mLocationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		if (mLocationManager==null) {
			// pop up a dialog
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("Oops!");
			builder.setMessage("Location service is unavailable!!!Please try it later!");
			AlertDialog dialog = builder.create();
			dialog.show();
			
			// go back to main activity
			Intent intent = new Intent(SendPhotoActivity.this, StartActivity.class);
			startActivity(intent);
	
		}
		
		
		
		// when activity first created, takePhotos();
		takePhoto();
				
		mRetakeButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(!isCurrentImageSubmitted&&mMediaUri!=null) {
//					getContentResolver().delete(mMediaUri, null, null);
					File deleteFile = new File(mMediaUri.toString());
					deleteFile.delete();
					Log.i(TAG,"deleteFile:" + deleteFile);
//					sendBroadcast(new Intent(Intent.ACTION_MEDIA_MOUNTED, Uri.parse("file://" + Environment.getExternalStorageDirectory())));	
				}
				takePhoto();
			}
		});
		
		mSubmitButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				submit();
				Intent intent = new Intent(SendPhotoActivity.this, ChooseMultiPhotoActivity.class);
				startActivity(intent);
				
				
			}
		});

	}
	
	/**
	 * submit photo and text to server
	 */
	protected void submit() {
		

		
		if(mLocation==null) {
//			new GetLoactionTask().execute();
			
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("Oops!");
			builder.setMessage("Location service is unavailable!!!Please re-submit later!");
			AlertDialog dialog = builder.create();
			dialog.show();
			return;
		}
		// submit photo
		isCurrentImageSubmitted = true;
		
		byte[] fileBytes = FileHelper.getByteArrayFromFile(SendPhotoActivity.this, mMediaUri);
		
		if(fileBytes==null) {
			return;
		} else {

			fileBytes = FileHelper.reduceImageForUpload(fileBytes);

			String fileName = FileHelper.getFileName(this, mMediaUri, TYPE_IMAGE);
			Log.i(TAG, "FILE name"+fileName);
			
		}

		// submit additional info
		mComment = mEditText.getText().toString();
		// mTimeStamp
		double longitude = mLocation.getLongitude();
		double latidude = mLocation.getLatitude();
		String additionalInfo = JsonHandler.additionalInfo(mTimeStamp, mComment, latidude, longitude);
		
		// encapsulate the message
		RequestParams params = new RequestParams();
		params.put(HttpConstants.SEND_IMAGE_KEY, new ByteArrayInputStream(fileBytes));
		params.put(HttpConstants.SEND_ADDINFO_KEY, additionalInfo);
		AsyncHttpClient client = new AsyncHttpClient();
		client.post(HttpConstants.UP_LOAD_URL, params, new AsyncHttpResponseHandler() {
			
			@Override
			public void onSuccess(int arg0, String feedback) {
//				super.onSuccess(arg0, arg1);
				Toast.makeText(SendPhotoActivity.this, "Send Successfully!", Toast.LENGTH_LONG).show();
				
				
				Intent intent = new Intent(SendPhotoActivity.this, ChooseMultiPhotoActivity.class);
				
				intent.setType("text/plain");  
				intent.putExtra(android.content.Intent.EXTRA_TEXT, feedback);
				
				
			}
			
		});
		
	}
	
	
	
	
	
	
	
	
	private void takePhoto() {		
		isCurrentImageSubmitted = false;
		Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		
		mMediaUri = getOutputMediaFileUri();
		if(mMediaUri==null) {
			// display an error
			Toast.makeText(SendPhotoActivity.this, "mMedia is null", Toast.LENGTH_LONG).show();
		} else {
			// the image will automatically stored
			takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, mMediaUri);
			startActivityForResult(takePhotoIntent, TAKE_PHOTO_REQUEST);
//			new GetLoactionTask().execute();

		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		Log.i(TAG,"request: " + requestCode +" result: " + resultCode);
		if(resultCode==RESULT_OK) {
			if(requestCode==TAKE_PHOTO_REQUEST) {
				// display on ImageView
//				mImageView.setImageURI(mMediaUri);
				Picasso.with(SendPhotoActivity.this).load(mMediaUri.toString()).into(mImageView);
			}
			
		} else if(resultCode==RESULT_CANCELED){
			Toast.makeText(SendPhotoActivity.this, "RESULT_CANCELED", Toast.LENGTH_LONG).show();
			
		}	
	}
	
	private boolean isExternalStorageAvailable() {
		String state = Environment.getExternalStorageState();
		if(state.equals(Environment.MEDIA_MOUNTED)) {
			return true;
		} else return false;
	}

	protected Uri getOutputMediaFileUri() {
		// to be safe, you should check SD Card is mounted
		// using Environment.getExternalStorageState() before doing this
		if (isExternalStorageAvailable()) {
			// 1. get the external storage directory
			String storeDir = getString(R.string.store_directory);
			File mediaStorageDir = new File(
					Environment
							.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
					storeDir);
			Log.i(TAG, mediaStorageDir.getPath());
			// 2. create the sub dire
			if (!mediaStorageDir.exists()) {
				// File.mkdirs() will make directories along this path
				if (!mediaStorageDir.mkdirs()) {
					Log.e(TAG, "Fail to make directory.");
					return null;
				}
				;
			}
			// 3. create the file name
			// 4. create the file
			File mediaFile;
			Date now = new Date();
			mTimeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
					Locale.US).format(now);
			Toast.makeText(SendPhotoActivity.this, "send time: " + mTimeStamp, Toast.LENGTH_LONG).show();
			String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss",
					Locale.US).format(now);
			String path = mediaStorageDir.getPath() + File.separator;

			mediaFile = new File(path + "IMG_" + timeStamp + ".jpg");

			Toast.makeText(SendPhotoActivity.this , "File path: " + Uri.fromFile(mediaFile),Toast.LENGTH_LONG).show();;
			Log.d(TAG, "File path: " + Uri.fromFile(mediaFile));
			// 5. create the file Uri
			return Uri.fromFile(mediaFile);

		} else {
			return null;
		}

	}
	
	class GetLoactionTask extends AsyncTask<Object, Object, Location> {


		@Override
		protected Location doInBackground(Object... args) {
			return getLocation();
		}
		
		@Override
		protected void onPostExecute(Location result) {
			mLocation = result;
			Toast.makeText(SendPhotoActivity.this, "Longitude: " + mLocation.getLongitude(), Toast.LENGTH_LONG).show();
			
		}
		
		private Location getLocation() {
			Location bestResult = null;
			float bestAccuracy = Float.MAX_VALUE;
			if(mLocationManager==null) return null;
			List<String> matchingProviderStrings = mLocationManager.getAllProviders();
			for(String provider : matchingProviderStrings) {
				Location location = mLocationManager.getLastKnownLocation(provider);
				if(location!=null) {
					float accuracy = location.getAccuracy();
					if(accuracy < bestAccuracy) {
						bestResult = location;
						bestAccuracy = accuracy;
					}	
				}
			}		
			Log.i(TAG, "Longitude: " + bestResult.getLongitude());
			Log.i(TAG, "Latitude: " + bestResult.getLatitude());
			return bestResult;
		}
	}

	

}
