/**
 * 
 */
package ics.cs237.childseeking.activity;

import android.R.integer;
import android.net.Uri;

/**
 * @author CHazyhabiT
 *
 */
public class ImageEntity {

    private Uri imageUri;
    private String id;
    private boolean isSelected;
      
    public ImageEntity(Uri imageUri, String id) {  
        this.imageUri = imageUri;  
        this.id = id;
        this.isSelected = false;
    }  
      
    public Uri getImageUri() {  
        return imageUri;  
    }  
    
    public String getId() {
    	return id;
    }
 
    public boolean isSelected() {  
        return isSelected;  
    }  

    public void setSelected(boolean value) {
    	isSelected = value;
    }
	
}
